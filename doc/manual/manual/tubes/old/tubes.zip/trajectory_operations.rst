.. _sec-trajectories-operations:

Operations on trajectories
==========================

Arithmetic and calculus
-----------------------

Operations such as ``x+y`` or ``sin(x)`` act on stored samples, with linear interpolation of the result[tu es sûr ? pourquoi on aurait une interpolation si les calculs se font sur un même échantillonnage de chaque côté ?]. Two sampled trajectories must have identical timestamps for arithmetic operations.

For a scalar or vector trajectory :math:`x`, ``primitive(dt)`` approximates the integral

.. math::

   p(t)=\int_{t_0}^{t}x(\tau)\,d\tau,\qquad p(t_0)=0,

using the trapezoidal rule, with integration step ``dt``. For a ``SampledTraj``, ``primitive()`` instead integrates over its existing sample intervals:

.. math::

   p(t_{i+1})=p(t_i)+\frac{t_{i+1}-t_i}{2}(x_i+x_{i+1}).

``derivative()`` approximates the derivative of a sampled trajectory by finite differences. These numerical operations do not provide guaranteed bounds.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-ops-calculus-beg]
      :end-before: [traj-ops-calculus-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-ops-calculus-beg]
      :end-before: [traj-ops-calculus-end]
      :dedent: 4

For further arithmetic and elementary functions, see :doc:`trajectory_reference`.

Cartesian products
------------------

``traj_cart_prod(x,y,...)`` [préférer "x1,x2,..." au lieu de "x,y,..."] combines scalar or vector sampled trajectories into a vector trajectory. All inputs must have identical timestamps; otherwise align them first, for example with ``sampled_as()``.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-ops-cartprod-beg]
      :end-before: [traj-ops-cartprod-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-ops-cartprod-beg]
      :end-before: [traj-ops-cartprod-end]
      :dedent: 4

Unwrapping periodic signals
---------------------------

``continuous_traj()`` removes apparent jumps in a sampled scalar signal, for instance a heading crossing its angular discontinuity.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-ops-continuous-beg]
      :end-before: [traj-ops-continuous-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-ops-continuous-beg]
      :end-before: [traj-ops-continuous-end]
      :dedent: 4

The current implementation estimates the period from the observed codomain diameter rather than from an explicitly supplied period. Check the result when the observed values do not span a complete cycle.
[développer un peu plus, comme tu l'avais fait avant]

Applying analytic functions
---------------------------

``f.traj_eval(x,y,...)`` [pareil, préférer x1,x2.. pour les entrées] applies an ``AnalyticFunction`` to sampled trajectories. The result is sampled at the timestamps of the first input, using interpolation for other inputs where needed. By comparison, ``f.tube_eval(...)`` evaluates interval enclosures on the shared temporal partition of the input tubes.

For example, given a heading :math:`\theta(t)` and a speed :math:`v(t)`, an analytic function computes the Cartesian velocity components:

.. math::

   \mathbf{u}(t)=\begin{pmatrix}v(t)\cos\theta(t)\\v(t)\sin\theta(t)\end{pmatrix}.

[dans l'exemple ci-dessous, il faudrait que le nom des variables rappel l'équation]
.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-ops-eval-beg]
      :end-before: [traj-ops-eval-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-ops-eval-beg]
      :end-before: [traj-ops-eval-end]
      :dedent: 4

For a vector-valued input trajectory, use a ``VectorVar``:

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-ops-fun-vector-beg]
      :end-before: [traj-ops-fun-vector-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-ops-fun-vector-beg]
      :end-before: [traj-ops-fun-vector-end]
      :dedent: 4

Using a trajectory in an analytic expression
--------------------------------------------

``as_function()`` makes a trajectory available inside an analytic expression of time. This is useful when an expression depends on an existing time series.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-ops-asfunction-beg]
      :end-before: [traj-ops-asfunction-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-ops-asfunction-beg]
      :end-before: [traj-ops-asfunction-end]
      :dedent: 4

The trajectory operator currently supports forward evaluation but not general backward contraction or derivative propagation through the expression.

Converting trajectories and tubes
---------------------------------

``SlicedTube(td,traj)`` encloses the represented trajectory on a temporal partition. To enclose an unknown physical signal, the resulting tube must also account for measurement and interpolation uncertainty. Conversely, ``tube.mid()`` gives a numerical midpoint trajectory, without retaining the tube's uncertainty.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-ops-tube-beg]
      :end-before: [traj-ops-tube-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-ops-tube-beg]
      :end-before: [traj-ops-tube-end]
      :dedent: 4

See :doc:`tube_operations` for interval-based counterparts and :doc:`trajectory_io` for serialization.
