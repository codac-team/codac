.. _sec-trajectories-analytictraj:

The AnalyticTraj class
======================

``AnalyticTraj`` represents a trajectory defined by a function of time, rather than by stored samples. It combines a temporal domain and an ``AnalyticFunction`` with one scalar input.

Construction
------------

Define a ``ScalarVar`` for time, create an ``AnalyticFunction`` and pass the domain before the function to ``AnalyticTraj``.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-analytic-create-beg]
      :end-before: [traj-analytic-create-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-analytic-create-beg]
      :end-before: [traj-analytic-create-end]
      :dedent: 4

Evaluation
----------

``x(t)`` evaluates the function at one time. ``x([a,b])`` uses interval evaluation to enclose all values over the interval, possibly with overestimation due to interval dependencies.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-analytic-eval-beg]
      :end-before: [traj-analytic-eval-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-analytic-eval-beg]
      :end-before: [traj-analytic-eval-end]
      :dedent: 4

Sampling
--------

``sampled(dt)`` constructs a ``SampledTraj`` at regular instants, including the final time. The resulting interpolation is generally different from the original analytic function between samples.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-analytic-sampled-beg]
      :end-before: [traj-analytic-sampled-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-analytic-sampled-beg]
      :end-before: [traj-analytic-sampled-end]
      :dedent: 4

Other operations
----------------

``tdomain()``, ``codomain()``, ``size()`` and ``truncate_tdomain()`` work as for other trajectories. ``sampled_as(reference)`` evaluates at the reference timestamps; ``as_function()`` embeds the trajectory into an analytic expression.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-analytic-advanced-beg]
      :end-before: [traj-analytic-advanced-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-analytic-advanced-beg]
      :end-before: [traj-analytic-advanced-end]
      :dedent: 4

For numerical integration with ``primitive(dt)``, see :doc:`trajectory_operations`. An analytic trajectory may also initialize a :doc:`slicedtube`. Its symbolic expression is not serialized directly; see :doc:`trajectory_io`.
