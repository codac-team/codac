.. _sec-trajectories-io:

Trajectory input, output and visualization
==========================================

External measurements
---------------------

No special CSV reader is required: parse the time/value columns and insert samples using ``set(value,time)``. The example reads CSV-formatted data from a stream; it can be replaced by a file stream when loading a dataset.
[ici, donner dans un bloc-code un exemple très simple de CSV sur 3/4 lignes, puis donner l'exemple de code pour le lire un peu plus loin, comme si le bloc précédent était enregistré dans un fichier data.csv qu'on chargerait ici. C'est plus explicite]

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-io-csv-beg]
      :end-before: [traj-io-csv-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-io-csv-beg]
      :end-before: [traj-io-csv-end]
      :dedent: 4

NumPy archives
--------------

In Python, a ``.npz`` archive can supply arrays of timestamps and values. Such an archive is distinct from Codac's binary serialization.
[memory.seek(0) sert à quoi ? Ajouter un commentaire en fin de ligne]

.. literalinclude:: src.py
  :language: python
  :start-after: [traj-sampled-npz-beg]
  :end-before: [traj-sampled-npz-end]
  :dedent: 4

Binary serialization
--------------------

``serialize`` and ``deserialize`` save and restore ``SampledTraj`` objects in binary form. The ``.cdc`` extension is conventional. ``AnalyticTraj`` has no direct serializer; sample it first to save a numerical approximation of its values.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [traj-ops-serialization-beg]
      :end-before: [traj-ops-serialization-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [traj-ops-serialization-beg]
      :end-before: [traj-ops-serialization-end]
      :dedent: 4

The binary format is primarily intended for compatible Codac builds, not as a portable interchange format. See :ref:`sec-tools-serialization` for details.

Visualization
-------------

Use ``Figure2D.plot_trajectory`` for scalar time series and ``Figure2D.plot_trajectories`` for vector time series. Spatial trajectories can be displayed with ``DefaultFigure.draw_trajectory``. See :doc:`../visualization/functions`.
