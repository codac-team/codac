.. _sec-trajectories:

Trajectories
============

A trajectory describes a time-dependent value :math:`x(\cdot):[t_0,t_f]\to\mathbb{R}^n`. Two representations are available:

* :doc:`sampledtraj`: time/value samples with linear interpolation.
* :doc:`analytictraj`: a known expression of time, evaluated through an ``AnalyticFunction``.

``SampledTraj`` is useful for measurements and numerical results while ``AnalyticTraj`` is useful for known time laws and simulations. Both support scalar and vector values, and sampled trajectories also support matrices.

Times are represented by ``double`` values [with user-defined units and origin[un peu inutile comme précision ?]]. Trajectories combined in an operation must use consistent time conventions. A ``SampledTraj`` is an interpolated numerical signal, not an uncertainty bound; :doc:`slicedtube` represents sets of admissible values at each time. [à quoi sert cette dernière phrase ?]

For common operations, evaluation by analytic functions and conversions to tubes, see :doc:`trajectory_operations`. For input/output and the API inventory, see :doc:`trajectory_io` and :doc:`trajectory_reference`.
[plutôt que cette dernière phrase, faire un rappel du sommaire ici, contenant les pages associées au trajectories]