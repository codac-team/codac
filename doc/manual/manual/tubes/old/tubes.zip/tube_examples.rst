.. _sec-domains-tubes-examples:

Programming examples with sliced tubes
======================================

  Main author: `Simon Rohou <https://www.simon-rohou.fr/research/>`_

This page gathers a few short examples derived from the current C++ and Python tests. They are intended as practical entry points for the tube API.[inutile de dire que ça vient des tests, aucun intérêt pour le lecteur]

Example 1: building and evaluating a scalar tube
------------------------------------------------

The following example builds a scalar tube over a sampled temporal domain and assigns different values on successive temporal intervals.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [tube-example-1-beg]
      :end-before: [tube-example-1-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [tube-example-1-beg]
      :end-before: [tube-example-1-end]
      :dedent: 4

[la syntaxe python x.set([2,8], [1,2]) est plus courte que celle en C++ x.set(Interval(2,8), Interval(1,2));. Harmoniser celle en C++]

This evaluation pattern appears repeatedly in the tests, both for scalar tubes and vector-valued tubes.[quel est l'intérêt de cette phrase ?]

Example 2: refining a temporal domain from a tube update
--------------------------------------------------------

Local assignments refine the shared temporal partition when necessary.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [tube-example-2-beg]
      :end-before: [tube-example-2-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [tube-example-2-beg]
      :end-before: [tube-example-2-end]
      :dedent: 4

The tests explicitly check that such assignments change the number of temporal slices. [à retirer ou bien à reformuler pour ne pas le présenter sous la forme d'un test]

Example 3: tube from an analytic function
-----------------------------------------

A sliced tube can be initialized by evaluating an analytic inclusion function on each temporal slice.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [tube-example-3-beg]
      :end-before: [tube-example-3-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [tube-example-3-beg]
      :end-before: [tube-example-3-end]
      :dedent: 4

This is especially convenient when you want a sampled enclosure of a known time function before running contractors or geometric operations.
[rendre cet exemple ci-dessus plus didactique, ou bien le retirer]

Example 4: derivative-aware slice reasoning
-------------------------------------------

The following pattern uses a derivative tube and ``CtcDeriv`` to sharpen a scalar slice. The slice can then build a polygonal enclosure used for refined evaluation or inversion.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [tube-example-4-beg]
      :end-before: [tube-example-4-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [tube-example-4-beg]
      :end-before: [tube-example-4-end]
      :dedent: 4

This pattern is directly exercised in the slice tests.[reformuler]

Example 5: integration and primitive tubes
------------------------------------------

The integration API supports point and interval queries and can also build a primitive tube.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [tube-example-5-beg]
      :end-before: [tube-example-5-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [tube-example-5-beg]
      :end-before: [tube-example-5-end]
      :dedent: 4

The integral tests provide many reference values for these operations and are a good source of further examples.[pareil]

Example 6: Cartesian product of tubes
-------------------------------------

When several sliced tubes share the same temporal domain, you can build a vector-valued tube by stacking their codomains slice by slice.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [tube-example-6-beg]
      :end-before: [tube-example-6-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [tube-example-6-beg]
      :end-before: [tube-example-6-end]
      :dedent: 4

[dans cet exemple, utiliser x1,x2... et faire l'exemple avec des variables mixtes : une scalaire avec une vectorielle]
This helper assumes that all input tubes share exactly the same temporal-domain object.

For the analogous operation on ``SampledTraj`` objects, see :ref:`sec-trajectories-operations` (``traj_cart_prod``).
