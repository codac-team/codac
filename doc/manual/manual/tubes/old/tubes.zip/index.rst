.. _sec-domains-tubes:
.. _sec-domains-tubes-trajectories:

Tubes & Trajectories
====================

Codac provides trajectories to represent time-dependent values and tubes to represent sets of possible trajectories. Both can be evaluated over time, combined with analytic functions, and used to describe dynamical systems.

A trajectory :math:`x(\cdot):[t_0,t_f]\rightarrow\mathbb{R}^n` assigns a value to each time. A tube :math:`[x](\cdot)` assigns a set of admissible values and thus represents the set of trajectories

.. math::

   \mathcal{T}([x])=\big\{x(\cdot)\mid \forall t\in[t_0,t_f],\ x(t)\in[x](t)\big\}.[je ne comprends pas cette formule, il faudrait mettre la formule classique disant que toutes les trajectoires considérées sont incluses dans le tube]

Contractors can reduce tubes while preserving all trajectories satisfying the constraints, which makes tubes useful for guaranteed state estimation.

Trajectories
------------

.. toctree::
  :maxdepth: 2

  trajectories
  sampledtraj
  analytictraj
  trajectory_operations
  trajectory_io
  trajectory_reference

Tubes
-----

.. toctree::
  :maxdepth: 2

  tubes_overview
  tdomain
  slice
  slicedtube
  tube_operations
  tube_io
  tube_reference
  tube_examples

See also :ref:`sec-tools-serialization` and :doc:`../visualization/functions`.
