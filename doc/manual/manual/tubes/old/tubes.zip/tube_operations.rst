.. _sec-domains-tubes-operations:

Operations on tubes
===================

[je ne vois pas réellement l'intérêt de cette page, il vaudrait mieux transférer son contenu vers les sections dédiées dans les autres pages]

Temporal alignment
------------------

Several tubes can share a ``TDomain``. Operations between tubes require the same temporal-domain object; changes to its partition are propagated to all attached tubes. See :doc:`tdomain`.

Set operations and Cartesian products
-------------------------------------

``x & y`` intersects interval enclosures, while ``x | y`` forms their interval hull. Arithmetic operates on slice codomains. ``tube_cart_prod(x,y,...)`` builds a vector tube from tubes sharing a ``TDomain``.
[ici aussi, préférer x1,x2 à x,y dans les notations]

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [tube-parity-algebra-beg]
      :end-before: [tube-parity-algebra-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [tube-parity-algebra-beg]
      :end-before: [tube-parity-algebra-end]
      :dedent: 4

Evaluation and analytic functions
---------------------------------

``x([a,b])`` encloses all values represented by the tube over the time interval. When a tube enclosing :math:`\dot x` is available, ``x([a,b],v)`` can sharpen this evaluation. ``f.tube_eval(x,y,...)`` applies an ``AnalyticFunction`` to tubes, computing interval enclosures over their common temporal partition. See :doc:`slicedtube` for examples.

Integration and constraints
---------------------------

For a tube :math:`[x]`, ``integral(t)`` encloses the values of

.. math::

   \int_{t_0}^{t}x(\tau)\,d\tau,\qquad x\in\mathcal{T}([x]).

``integral(t1,t2)`` allows interval time bounds. ``primitive()`` constructs a tube for accumulated integrals with an optional initial condition. Constraints such as :math:`\dot x=v` can be propagated using a contractor such as ``CtcDeriv``. See :doc:`slicedtube` for integration and inversion.

Connecting tubes and trajectories
---------------------------------

``SlicedTube(td,traj)`` encloses the represented analytic function or sampled interpolant on each slice. ``tube.mid()`` returns a numerical midpoint trajectory, without the uncertainty information stored in the tube.

.. tabs::

  .. group-tab:: Python

    .. literalinclude:: src.py
      :language: python
      :start-after: [tube-parity-conversion-beg]
      :end-before: [tube-parity-conversion-end]
      :dedent: 4

  .. group-tab:: C++

    .. literalinclude:: src.cpp
      :language: c++
      :start-after: [tube-parity-conversion-beg]
      :end-before: [tube-parity-conversion-end]
      :dedent: 4

For a detailed inventory, see :doc:`tube_reference`.
